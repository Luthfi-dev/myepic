"use strict";
exports.id = 544;
exports.ids = [544];
exports.modules = {

/***/ 544:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Ii: () => (/* binding */ artikelApi),
/* harmony export */   LY: () => (/* binding */ publicApi),
/* harmony export */   P4: () => (/* binding */ artikelPageApi),
/* harmony export */   QR: () => (/* binding */ reqTokenApi),
/* harmony export */   Xj: () => (/* binding */ cekMailApi),
/* harmony export */   ZC: () => (/* binding */ komentarApi),
/* harmony export */   b: () => (/* binding */ linkApi),
/* harmony export */   dg: () => (/* binding */ kategoriApi),
/* harmony export */   jh: () => (/* binding */ notifikasiApi),
/* harmony export */   nV: () => (/* binding */ verifyMailApi),
/* harmony export */   w: () => (/* binding */ signupApi)
/* harmony export */ });
/* unused harmony exports userApi, komentarCheckApi */
const linkApi = "https://ex.luth.my.id/api/media";
const publicApi = "https://ex.luth.my.id/media";
const artikelApi = "https://ex.luth.my.id/api/artikel";
const kategoriApi = "https://ex.luth.my.id/api/kategori";
const artikelPageApi = "https://ex.luth.my.id/api/artikelpage";
const userApi = "https://ex.luth.my.id/api/user";
const signupApi = "https://ex.luth.my.id/api/signup";
const verifyMailApi = "https://ex.luth.my.id/api/user/verify-activasi";
const cekMailApi = "https://ex.luth.my.id/api/user/cek-mail";
const reqTokenApi = "https://ex.luth.my.id/api/login";
const komentarApi = "https://ex.luth.my.id/api/komentar-review";
const komentarCheckApi = "https://ex.luth.my.id/api/komentar-review-cek";
const notifikasiApi = "https://ex.luth.my.id/api/notifikasi";


/***/ })

};
;