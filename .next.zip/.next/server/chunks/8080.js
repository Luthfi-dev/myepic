"use strict";
exports.id = 8080;
exports.ids = [8080];
exports.modules = {

/***/ 8080:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _utils_globals__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(544);
/* harmony import */ var _pages_axios_config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9873);
/* harmony import */ var _components_DataUser__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8533);







const ViewNotifikasi = ()=>{
    const [notifications, setNotifications] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const fifiAxios = (0,_pages_axios_config__WEBPACK_IMPORTED_MODULE_4__["default"])();
    const myUser = (0,_components_DataUser__WEBPACK_IMPORTED_MODULE_5__/* .DataUser */ .D)();
    const UserId = myUser !== null ? myUser.id_user : null;
    console.log(UserId);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        // Fungsi untuk mengambil data dari server
        const fetchData = async ()=>{
            if (myUser !== null) {
                try {
                    const response = await fifiAxios.get(`${_utils_globals__WEBPACK_IMPORTED_MODULE_6__/* .notifikasiApi */ .jh}?user_id=${UserId}`);
                    const data = response.data;
                    console.log(data);
                    // Filter data sesuai dengan status yang diinginkan
                    const filteredData = data.filter((item)=>{
                        return item.status === "pra-tolak" || item.status === "diterima";
                    });
                    // Ambil lima data teratas
                    const topFiveNotifications = filteredData.slice(0, 5);
                    setNotifications(data);
                } catch (error) {
                    console.error("Error fetching data:", error);
                }
            }
        };
        fetchData();
    }, [
        myUser
    ]);
    // useEffect(()=>{
    //   fetchData();
    // },[])
    function formatDateTime(dateTimeString) {
        // Buat objek Date dari dateTimeString
        const date = new Date(dateTimeString);
        // Dapatkan komponen tanggal, bulan, tahun, jam, dan menit
        const day = date.getDate();
        const month = date.getMonth() + 1; // Ingat, bulan dimulai dari 0 (Januari adalah 0)
        const year = date.getFullYear();
        const hours = date.getHours();
        const minutes = date.getMinutes();
        // Buat format jam dan tanggal yang diinginkan
        const formattedDateTime = `${day}/${month}/${year} ${hours}:${minutes}`;
        return formattedDateTime;
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "container",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "row card p-1",
            style: {
                display: "block"
            },
            children: [
                notifications.map((notification, index)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "m-5",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                                className: "dropdown-divider"
                            }),
                            notification.status === "ditolak" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                className: "btn btn-danger",
                                style: {
                                    marginLeft: "20px",
                                    marginTop: "-30px"
                                },
                                children: "Postingan ditolak"
                            }),
                            notification.status === "diterima" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h4", {
                                className: "btn btn-success",
                                style: {
                                    marginLeft: "20px",
                                    marginTop: "-30px"
                                },
                                children: [
                                    "Postingan ",
                                    notification.status
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                style: {
                                    border: "2px solid silver",
                                    marginTop: "-30px",
                                    padding: "20px 20px 10px 20px",
                                    borderRadius: "10px",
                                    boxShadow: "3px 3px 5px 2px silver"
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        dangerouslySetInnerHTML: {
                                            __html: notification.isi_notifikasi
                                        }
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        children: formatDateTime(notification.created_at)
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {})
                        ]
                    }, index)),
                notifications.length > 0 ? "" : "Belum ada notifikasi"
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ViewNotifikasi);


/***/ })

};
;