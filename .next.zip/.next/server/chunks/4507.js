"use strict";
exports.id = 4507;
exports.ids = [4507];
exports.modules = {

/***/ 4507:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  H: () => (/* binding */ MasterAdminLayout)
});

// UNUSED EXPORTS: metadata

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2167);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./utils/globals.js
var globals = __webpack_require__(544);
// EXTERNAL MODULE: ./pages/axios-config.js
var axios_config = __webpack_require__(9873);
// EXTERNAL MODULE: ./src/components/DataUser.js
var DataUser = __webpack_require__(8533);
;// CONCATENATED MODULE: ./src/components/MasterAdmin/MasterAdminHeader.js










const MasterAdminHeader = ()=>{
    const router = (0,router_.useRouter)();
    const myUser = (0,DataUser/* DataUser */.D)();
    // console.log("gggg", myUser);
    const [isSidebarOpen, setSidebarOpen] = (0,external_react_.useState)(false);
    const [notifications, setNotifications] = (0,external_react_.useState)([]);
    const [totalNotifications, setTotalNotifications] = (0,external_react_.useState)(0);
    const fifiAxios = (0,axios_config["default"])();
    (0,external_react_.useEffect)(()=>{
        // console.log("ini stttttt");
        const UserId = myUser !== null ? myUser.id_user : null;
        // console.log("iddd", UserId);
        // Fungsi untuk mengambil data dari server
        const fetchData = async ()=>{
            try {
                if (myUser !== null) {
                    const response = await fifiAxios.get(`${globals/* notifikasiApi */.jh}?user_id=${UserId}`);
                    const data = response.data;
                    // console.log("ini res data header", data);
                    // Filter data sesuai dengan status yang diinginkan
                    const filteredData = data.filter((item)=>{
                        return item.status === "ditolak" || item.status === "diterima";
                    });
                    // Ambil lima data teratas
                    const topFiveNotifications = filteredData.slice(0, 5);
                    setNotifications(topFiveNotifications);
                    setTotalNotifications(filteredData.length);
                }
            } catch (error) {
                console.error("Error fetching data:", error);
            }
        };
        fetchData();
    }, [
        myUser
    ]);
    function formatDateTime(dateTimeString) {
        // Buat objek Date dari dateTimeString
        const date = new Date(dateTimeString);
        // Dapatkan komponen tanggal, bulan, tahun, jam, dan menit
        const day = date.getDate();
        const month = date.getMonth() + 1; // Ingat, bulan dimulai dari 0 (Januari adalah 0)
        const year = date.getFullYear();
        const hours = date.getHours();
        const minutes = date.getMinutes();
        // Buat format jam dan tanggal yang diinginkan
        const formattedDateTime = `${day}/${month}/${year} ${hours}:${minutes}`;
        return formattedDateTime;
    }
    // Fungsi untuk menampilkan atau menyembunyikan sidebar
    function tampilkanToggleSidebar() {
        setSidebarOpen(!isSidebarOpen);
    }
    // Efek ini akan dipanggil setiap kali URL berubah
    (0,external_react_.useEffect)(()=>{
        // Tutup sidebar saat URL berubah
        setSidebarOpen(false);
    }, [
        router.asPath
    ]); // Memantau perubahan URL
    // Set class pada body sesuai dengan status sidebar
    (0,external_react_.useEffect)(()=>{
        const body = document.body;
        if (isSidebarOpen) {
            body.classList.add("toggle-sidebar");
        } else {
            body.classList.remove("toggle-sidebar");
        }
    }, [
        isSidebarOpen
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("header", {
        id: "header",
        className: "header fixed-top d-flex align-items-center",
        style: {
            zIndex: "9999"
        },
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "d-flex align-items-center justify-content-between",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)((link_default()), {
                        href: "index.html",
                        className: "logo d-flex align-items-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                src: "/assets/img/logo.png",
                                alt: "",
                                width: 40,
                                height: 50
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("span", {
                                className: "d-none d-lg-block",
                                children: "Thinkepic"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("i", {
                        className: "bi bi-list toggle-sidebar-btn",
                        onClick: tampilkanToggleSidebar
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime.jsx("nav", {
                className: "header-nav ms-auto",
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                    className: "d-flex align-items-center",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                            className: "nav-item dropdown",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)((link_default()), {
                                    className: "nav-link nav-icon",
                                    href: "#",
                                    "data-bs-toggle": "dropdown",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("i", {
                                            className: "bi bi-bell"
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("span", {
                                            className: "badge bg-primary badge-number",
                                            children: totalNotifications
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                    className: "dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                            className: "dropdown-header",
                                            children: [
                                                "Kamu punya ",
                                                totalNotifications,
                                                " notifikasi",
                                                notifications.length > 0 ? /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                    href: "/super-admin/notifikasi",
                                                    children: /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                        className: "badge rounded-pill bg-primary p-2 ms-2",
                                                        children: "View all"
                                                    })
                                                }) : /*#__PURE__*/ jsx_runtime.jsx("p", {})
                                            ]
                                        }),
                                        notifications.map((notification, index)=>/*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime.jsx("hr", {
                                                        className: "dropdown-divider"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                        className: "notification-item",
                                                        children: [
                                                            notification.status === "pra-tolak" && /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                                className: "bi bi-x-circle text-danger"
                                                            }),
                                                            notification.status === "diterima" && /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                                className: "bi bi-check-circle text-success"
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                                children: [
                                                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("h4", {
                                                                        children: [
                                                                            "Postingan ",
                                                                            notification.status
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                                        dangerouslySetInnerHTML: {
                                                                            __html: notification.isi_notifikasi
                                                                        }
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                                        children: formatDateTime(notification.created_at)
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }, index)),
                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime.jsx("hr", {
                                                className: "dropdown-divider"
                                            })
                                        }),
                                        notifications.length > 0 ? /*#__PURE__*/ jsx_runtime.jsx("li", {
                                            className: "dropdown-footer",
                                            children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                                href: "/super-admin/notifikasi",
                                                children: "Show all notifications"
                                            })
                                        }) : /*#__PURE__*/ jsx_runtime.jsx("li", {})
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                            className: "nav-item dropdown pe-3",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)((link_default()), {
                                    className: "nav-link nav-profile d-flex align-items-center pe-0",
                                    href: "#",
                                    "data-bs-toggle": "dropdown",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                            width: 40,
                                            height: 50,
                                            src: "/assets/img/profile-img.jpg",
                                            alt: "Profile",
                                            className: "rounded-circle"
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("span", {
                                            className: "d-none d-md-block dropdown-toggle ps-2",
                                            children: "Master Admin"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                    className: "dropdown-menu dropdown-menu-end dropdown-menu-arrow profile",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                            className: "dropdown-header",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime.jsx("h6", {
                                                    children: "MasterAdmin"
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                    children: "Editor"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime.jsx("hr", {
                                                className: "dropdown-divider"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)((link_default()), {
                                                className: "dropdown-item d-flex align-items-center",
                                                href: "users-profile.html",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                        className: "bi bi-person"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                        children: "My Profile"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime.jsx("hr", {
                                                className: "dropdown-divider"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)((link_default()), {
                                                className: "dropdown-item d-flex align-items-center",
                                                href: "users-profile.html",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                        className: "bi bi-gear"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                        children: "Account Settings"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime.jsx("hr", {
                                                className: "dropdown-divider"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)((link_default()), {
                                                className: "dropdown-item d-flex align-items-center",
                                                href: "pages-faq.html",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                        className: "bi bi-question-circle"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                        children: "Need Help?"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                            children: /*#__PURE__*/ jsx_runtime.jsx("hr", {
                                                className: "dropdown-divider"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("li", {
                                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)((link_default()), {
                                                className: "dropdown-item d-flex align-items-center",
                                                href: "#",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                        className: "bi bi-box-arrow-right"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                        children: "Sign Out"
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const MasterAdmin_MasterAdminHeader = (MasterAdminHeader);

;// CONCATENATED MODULE: ./src/components/MasterAdmin/MasterAdminNav.js




const MasterAdminNav = ()=>{
    const router = (0,router_.useRouter)();
    // Fungsi untuk mengecek apakah menu aktif
    const isMenuActive = (path)=>{
        return router.pathname === path ? "active" : "";
    };
    return /*#__PURE__*/ jsx_runtime.jsx(jsx_runtime.Fragment, {
        children: /*#__PURE__*/ jsx_runtime.jsx("aside", {
            id: "sidebar",
            className: "sidebar",
            style: {
                zIndex: "999"
            },
            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                className: "sidebar-nav",
                id: "sidebar-nav",
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                        className: `nav-item ${isMenuActive("/master-admin")}`,
                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                            href: "/master-admin",
                            legacyBehavior: true,
                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                className: "nav-link ",
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx("i", {
                                        className: "bi bi-grid"
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("span", {
                                        children: "Dashboard"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                        className: `nav-item ${isMenuActive("/master-admin/verifikasi")}`,
                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                            href: "/master-admin/verifikasi",
                            legacyBehavior: true,
                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                className: "nav-link collapsed",
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx("i", {
                                        className: "bi bi-card-checklist"
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("span", {
                                        children: "Verifikasi"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                        className: `nav-item ${isMenuActive("/master-admin/postingan")}`,
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                href: "#",
                                legacyBehavior: true,
                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                    className: "nav-link collapsed",
                                    "data-bs-target": "#forms-nav",
                                    "data-bs-toggle": "collapse",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("i", {
                                            className: "bi bi-journal-text"
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("span", {
                                            children: "Postingan"
                                        }),
                                        /*#__PURE__*/ jsx_runtime.jsx("i", {
                                            className: "bi bi-chevron-down ms-auto"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                id: "forms-nav",
                                className: "nav-content collapse ",
                                "data-bs-parent": "#sidebar-nav",
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                            href: "/master-admin/data-posting",
                                            legacyBehavior: true,
                                            children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("span", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                            className: "ri-file-list-3-fill",
                                                            style: {
                                                                fontSize: "12pt"
                                                            }
                                                        }),
                                                        " ",
                                                        "Semua Artikel"
                                                    ]
                                                })
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                            href: "/master-admin/posting",
                                            legacyBehavior: true,
                                            children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("span", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                            className: "ri-add-circle-line",
                                                            style: {
                                                                fontSize: "12pt"
                                                            }
                                                        }),
                                                        " ",
                                                        "Artikel"
                                                    ]
                                                })
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                            href: "/master-admin/category",
                                            legacyBehavior: true,
                                            children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("span", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                            className: "ri-add-circle-fill",
                                                            style: {
                                                                fontSize: "12pt"
                                                            }
                                                        }),
                                                        " ",
                                                        "Kategori"
                                                    ]
                                                })
                                            })
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                        className: `nav-item ${isMenuActive("/master-admin/media")}`,
                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                            href: "/master-admin/media",
                            legacyBehavior: true,
                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                className: "nav-link collapsed",
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx("i", {
                                        className: "bi bi-bank"
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("span", {
                                        children: "Media"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                        className: "nav-heading",
                        children: "Settings"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                        className: `nav-item ${isMenuActive("/master-admin/profile")}`,
                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                            href: "users-profile.html",
                            legacyBehavior: true,
                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                className: "nav-link collapsed",
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx("i", {
                                        className: "bi bi-person"
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("span", {
                                        children: "Profile"
                                    })
                                ]
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                        className: `nav-item ${isMenuActive("/master-admin/logout")}`,
                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                            href: "#",
                            legacyBehavior: true,
                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                className: "nav-link collapsed",
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx("i", {
                                        className: "bi bi-box-arrow-in-right"
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("span", {
                                        children: "LogOut"
                                    })
                                ]
                            })
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const MasterAdmin_MasterAdminNav = (MasterAdminNav);

;// CONCATENATED MODULE: ./src/components/MasterAdmin/MasterAdminLayout.js
// src/app/MasterAdminLayout.js


// import "./globals.css";


// import { Inter } from "next/font/google";
// const inter = Inter({ subsets: ["latin"] });
const metadata = {
    title: "thinkepic CMS.",
    description: "thinkepic"
};
function MasterAdminLayout({ children }) {
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime.jsx(MasterAdmin_MasterAdminHeader, {}),
            /*#__PURE__*/ jsx_runtime.jsx(MasterAdmin_MasterAdminNav, {}),
            /*#__PURE__*/ jsx_runtime.jsx("main", {
                id: "main",
                className: "main",
                children: /*#__PURE__*/ jsx_runtime.jsx("section", {
                    className: "section dashboard",
                    children: children
                })
            }),
            /*#__PURE__*/ jsx_runtime.jsx("footer", {
                id: "footer",
                className: "footer",
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "copyright",
                    children: [
                        "\xa9 Copyright",
                        " ",
                        /*#__PURE__*/ jsx_runtime.jsx("strong", {
                            children: /*#__PURE__*/ jsx_runtime.jsx("span", {
                                children: "Thinkepic"
                            })
                        }),
                        ". All Rights Reserved"
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime.jsx("a", {
                href: "#",
                className: "back-to-top d-flex align-items-center justify-content-center",
                children: /*#__PURE__*/ jsx_runtime.jsx("i", {
                    className: "bi bi-arrow-up-short"
                })
            }),
            /*#__PURE__*/ jsx_runtime.jsx("script", {
                src: "/assets/vendor/apexcharts/apexcharts.min.js",
                async: true
            }),
            /*#__PURE__*/ jsx_runtime.jsx("script", {
                src: "/assets/vendor/bootstrap/js/bootstrap.bundle.min.js",
                async: true
            }),
            /*#__PURE__*/ jsx_runtime.jsx("script", {
                src: "/assets/vendor/chart.js/chart.umd.js",
                async: true
            }),
            /*#__PURE__*/ jsx_runtime.jsx("script", {
                src: "/assets/vendor/echarts/echarts.min.js",
                async: true
            }),
            /*#__PURE__*/ jsx_runtime.jsx("script", {
                src: "/assets/vendor/quill/quill.min.js",
                async: true
            }),
            /*#__PURE__*/ jsx_runtime.jsx("script", {
                src: "/assets/vendor/simple-datatables/simple-datatables.js",
                async: true
            }),
            /*#__PURE__*/ jsx_runtime.jsx("script", {
                src: "/assets/vendor/php-email-form/validate.js",
                async: true
            }),
            /*#__PURE__*/ jsx_runtime.jsx("script", {
                src: "/assets/js/main.js",
                async: true
            })
        ]
    });
}


/***/ })

};
;