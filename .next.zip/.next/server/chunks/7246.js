exports.id = 7246;
exports.ids = [7246];
exports.modules = {

/***/ 2012:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils_globals__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(544);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _pages_axios_config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9873);






const AdminContent = ({ kData, modal })=>{
    const [isFileSelected, setIsFileSelected] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [selectedFiles, setSelectedFiles] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    // const [mediaData, setMediaData] = useState({ images: [], videos: [] });
    const [currentPage, setCurrentPage] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const [activeTab, setActiveTab] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("image");
    const [totalMedia, setTotalMedia] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const [dataAll, setDataAll] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const fifiAxios = (0,_pages_axios_config__WEBPACK_IMPORTED_MODULE_4__["default"])();
    const handleMediaClick = (imageName)=>{
        kData.media = imageName;
        modal(false);
        console.log(kData);
    };
    console.log(_utils_globals__WEBPACK_IMPORTED_MODULE_5__/* .publicApi */ .LY);
    // GET DATA API
    const fetchData = async ()=>{
        try {
            let mediaType = activeTab === "image" ? "image" : "video";
            // Mengambil data total
            const countResponse = await fifiAxios.get(`${_utils_globals__WEBPACK_IMPORTED_MODULE_5__/* .linkApi */ .b}?page=${currentPage}&type=${mediaType}`);
            const countData = countResponse.data;
            const totalCount = countData.total;
            setTotalMedia(totalCount);
            // Mengambil data keseluruhan
            const response = await fifiAxios.get(`${_utils_globals__WEBPACK_IMPORTED_MODULE_5__/* .linkApi */ .b}?page=${currentPage}&type=${mediaType}`);
            const dataAmbil = response.data; // Menggunakan variabel 'response' untuk mengambil data, bukan 'countResponse'
            // Set data ke state
            setDataAll(dataAmbil.data);
            console.log("Data yang diambil:", dataAmbil.data, "total media", totalMedia);
        } catch (error) {
            console.error("Terjadi kesalahan:", error);
        }
    };
    const handlePageChange = (page)=>{
        setCurrentPage(page);
    };
    const handleTabChange = (tab)=>{
        setActiveTab(tab);
        setCurrentPage(1);
    };
    const handleFileChange = (event)=>{
        const files = event.target.files;
        setIsFileSelected(files.length > 0);
        setSelectedFiles([
            ...files
        ]);
    };
    const handleFileUpload = async ()=>{
        if (!selectedFiles.length) {
            alert("Pilih file terlebih dahulu");
            return;
        }
        const formData = new FormData();
        selectedFiles.forEach((file)=>{
            formData.append("nama", file);
        });
        formData.append("user_id", "1");
        try {
            const response = await fifiAxios.post(`${_utils_globals__WEBPACK_IMPORTED_MODULE_5__/* .linkApi */ .b}`, formData, {
                headers: {
                    "Content-Type": "multipart/form-data"
                }
            });
            if (response.status === 200) {
                alert("Media berhasil diunggah");
                fetchData(); // Pastikan bahwa fetchData() bekerja dengan benar untuk memperbarui data.
            } else {
                alert("Terjadi kesalahan saat mengunggah media");
            }
        } catch (error) {
            console.error("Terjadi kesalahan:", error);
            alert("Terjadi kesalahan saat mengunggah media");
        }
    };
    const deleteMedia = async (mediaId)=>{
        try {
            const response = await fifiAxios.delete(`${_utils_globals__WEBPACK_IMPORTED_MODULE_5__/* .linkApi */ .b}/${mediaId}`);
            if (response.status === 200 || response.status === 204) {
                console.log("Media berhasil dihapus.");
                fetchData(); // Anda mungkin perlu mengeksekusi fungsi fetchData() untuk memperbarui data setelah penghapusan.
            } else {
                console.error("Gagal menghapus media.");
            }
        } catch (error) {
            console.error("Terjadi kesalahan:", error);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        fetchData();
    }, [
        currentPage,
        activeTab
    ]);
    // PAGENASI
    const renderPagination = ()=>{
        const totalPages = Math.ceil(totalMedia / 5);
        if (totalPages <= 1) {
            return null;
        }
        const currentPageIndex = currentPage - 1;
        const renderPageButton = (pageNumber)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                href: "#",
                onClick: ()=>handlePageChange(pageNumber),
                className: `page-link rounded-circle ${currentPage === pageNumber ? "active" : ""}`,
                children: pageNumber
            }, pageNumber);
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                "aria-label": "Page navigation example",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                    className: "pagination",
                    children: [
                        currentPage > 1 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                    href: "#",
                                    className: "btn btn-light bordered",
                                    onClick: ()=>handlePageChange(1),
                                    children: "previous"
                                }),
                                currentPage > 2 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    className: "ellipsis",
                                    children: "..."
                                })
                            ]
                        }),
                        currentPage > 1 && renderPageButton(currentPage - 1),
                        renderPageButton(currentPage),
                        currentPage < totalPages && renderPageButton(currentPage + 1),
                        currentPage < totalPages - 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                            className: "ellipsis",
                            children: "..."
                        }),
                        currentPage < totalPages - 1 && renderPageButton(totalPages),
                        currentPage < totalPages && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                            href: "#",
                            className: "btn btn-light bordered",
                            onClick: ()=>handlePageChange(totalPages),
                            children: "Next"
                        })
                    ]
                })
            })
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "row",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "col-xxl-12 col-md-12",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "card info-card sales-card p-2",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "card-body",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                className: "nav nav-tabs nav-tabs-bordered d-flex",
                                id: "borderedTabJustified",
                                role: "tablist",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: "nav-item flex-fill",
                                        role: "presentation",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            className: `nav-link w-100 ${activeTab === "image" ? "active" : ""}`,
                                            id: "home-tab",
                                            "data-bs-toggle": "tab",
                                            "data-bs-target": "#bordered-justified-home",
                                            type: "button",
                                            role: "tab",
                                            "aria-controls": "image",
                                            "aria-selected": activeTab === "image",
                                            onClick: ()=>handleTabChange("image"),
                                            children: "Image"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: "nav-item flex-fill",
                                        role: "presentation",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            className: `nav-link w-100 ${activeTab === "video" ? "active" : ""}`,
                                            id: "profile-tab",
                                            "data-bs-toggle": "tab",
                                            "data-bs-target": "#bordered-justified-profile",
                                            type: "button",
                                            role: "tab",
                                            "aria-controls": "videos",
                                            "aria-selected": activeTab === "video",
                                            onClick: ()=>handleTabChange("video"),
                                            children: "Videos"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: "nav-item flex-fill",
                                        role: "presentation",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            className: "nav-link w-100",
                                            id: "contact-tab",
                                            "data-bs-toggle": "tab",
                                            "data-bs-target": "#bordered-justified-contact",
                                            type: "button",
                                            role: "tab",
                                            "aria-controls": "upload",
                                            "aria-selected": "false",
                                            tabIndex: "-1",
                                            children: "Upload"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "tab-content pt-2",
                                id: "borderedTabJustifiedContent",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: `tab-pane fade ${activeTab === "image" ? "active show" : ""}`,
                                        id: "bordered-justified-home",
                                        role: "tabpanel",
                                        "aria-labelledby": "image-tab",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "row",
                                                children: dataAll.map((image)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "col-md-3 mb-3",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "d-flex flex-column align-items-center",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                                    src: `https://ex.luth.my.id/media/${image.nama}`,
                                                                    alt: image.id,
                                                                    width: 200,
                                                                    height: 200,
                                                                    objectFit: "cover",
                                                                    onClick: ()=>handleMediaClick(image.nama)
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                    onClick: ()=>deleteMedia(image.id),
                                                                    className: "btn btn-danger mt-2",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                        className: "bi bi-trash"
                                                                    })
                                                                })
                                                            ]
                                                        })
                                                    }, image.id))
                                            }),
                                            renderPagination()
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: `tab-pane fade ${activeTab === "video" ? "active show" : ""}`,
                                        id: "bordered-justified-profile",
                                        role: "tabpanel",
                                        "aria-labelledby": "videos-tab",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "row",
                                                children: dataAll.map((video)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        className: "col-md-3 mb-3",
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("video", {
                                                                controls: true,
                                                                width: "250",
                                                                height: "300",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("source", {
                                                                        src: `${_utils_globals__WEBPACK_IMPORTED_MODULE_5__/* .publicApi */ .LY}/${video.nama}`,
                                                                        onClick: ()=>handleMediaClick(video.nama)
                                                                    }),
                                                                    "Maaf, browser Anda tidak mendukung video ini."
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                                onClick: ()=>deleteMedia(video.id),
                                                                className: "btn btn-danger mt-2 btn-sm",
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                        className: "bi bi-trash"
                                                                    }),
                                                                    " Media"
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                                onClick: ()=>handleMediaClick(video.nama),
                                                                className: "btn btn-primary mt-2 btn-sm",
                                                                style: {
                                                                    backgroundColor: "#6776F4",
                                                                    color: "white"
                                                                },
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("i", {
                                                                        className: "bi bi-check"
                                                                    }),
                                                                    " Pilih"
                                                                ]
                                                            })
                                                        ]
                                                    }, video.id))
                                            }),
                                            renderPagination()
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "tab-pane fade",
                                        id: "bordered-justified-contact",
                                        role: "tabpanel",
                                        "aria-labelledby": "upload-tab",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "container mt-5",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "row justify-content-center",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "col-md-6",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "card",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                            className: "card-body",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: "text-center mb-3",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                                        src: "/assets/img/logos-upload.png",
                                                                        width: 200,
                                                                        height: 200,
                                                                        objectFit: "contain",
                                                                        alt: "Logo Upload",
                                                                        className: "img-fluid"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                                                    children: [
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                            className: "mb-3",
                                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                                                type: "file",
                                                                                name: "nama",
                                                                                className: "btn form-control btn-light",
                                                                                id: "media",
                                                                                multiple: true,
                                                                                onChange: handleFileChange
                                                                            })
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                            type: "button",
                                                                            className: "btn btn-dark w-100",
                                                                            onClick: handleFileUpload,
                                                                            disabled: !isFileSelected,
                                                                            children: "Upload"
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    })
                                                })
                                            })
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AdminContent);


/***/ }),

/***/ 1489:
/***/ (() => {



/***/ })

};
;