"use strict";
exports.id = 4234;
exports.ids = [4234];
exports.modules = {

/***/ 4234:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   l: () => (/* binding */ showDynamicAlert)
/* harmony export */ });
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_0__);

const showDynamicAlert = (pesan, tipe = "info")=>{
    let icon = "info";
    // Mengatur ikon berdasarkan tipe pesan yang diterima
    switch(tipe){
        case "success":
            icon = "success";
            break;
        case "successTime":
            icon = "success";
            break;
        case "error":
            icon = "error";
            break;
        case "errorTime":
            icon = "error";
            break;
        case "warning":
            icon = "warning";
            break;
        case "info":
            icon = "info";
            break;
        case "question":
            icon = "question";
            break;
        default:
            icon = "info"; // Default ke ikon informasi jika tipe tidak dikenali
    }
    // Jika tipe pesan adalah "success" (berhasil login), maka tambahkan timer
    if (tipe === "successTime") {
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire({
            icon,
            text: pesan,
            timer: 2000,
            showConfirmButton: false
        });
    } else if (tipe === "errorTime") {
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire({
            icon,
            text: pesan,
            timer: 2000,
            showConfirmButton: false
        });
    } else {
        // Jika tipe pesan bukan "success", tampilkan notifikasi tanpa timer
        sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire({
            icon,
            title: "Notifikasi",
            text: pesan,
            confirmButtonText: "OK",
            customClass: {
                confirmButton: "btn btn-primary"
            }
        });
    }
};


/***/ })

};
;