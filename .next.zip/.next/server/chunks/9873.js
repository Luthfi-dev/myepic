"use strict";
exports.id = 9873;
exports.ids = [9873];
exports.modules = {

/***/ 9873:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   useAxiosConfig: () => (/* binding */ useAxiosConfig)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5666);
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(crypto_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Contents_showDynamicAlert__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4234);
// pages/axios-config.js





// Fungsi untuk mengatur token akses
const setAccessToken = (axiosInstance, token)=>{
    if (token) {
        axiosInstance.defaults.headers.common["Authorization"] = `Bearer ${token}`;
    } else {
        // Hapus header otorisasi jika token tidak ada
        delete axiosInstance.defaults.headers.common["Authorization"];
    }
};
// Fungsi untuk mendekripsi token
const decryptToken = (ciphertext, secretKey)=>{
    const bytes = CryptoJS.AES.decrypt(ciphertext, secretKey);
    const decryptedData = JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
    return decryptedData;
};
// Fungsi kustom React Hook untuk konfigurasi Axios
function useAxiosConfig() {
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const axiosInstance = axios__WEBPACK_IMPORTED_MODULE_0___default().create();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        // Fungsi untuk menangani respons dari server
        const handleResponse = async (response)=>{
            if (response === undefined) {
                router.push("/auth/re-login");
                return;
            }
            if (response.status === 403) {
                // Jika respons adalah Forbidden (403), tampilkan pesan akses ditolak
                (0,_Contents_showDynamicAlert__WEBPACK_IMPORTED_MODULE_4__/* .showDynamicAlert */ .l)("Akses Dilarang ke halaman ini!", "errorTime");
            } else if (response.status === 401) {
                // Jika respons adalah Unauthorized (401), tampilkan pesan sesi berakhir
                (0,_Contents_showDynamicAlert__WEBPACK_IMPORTED_MODULE_4__/* .showDynamicAlert */ .l)("Sesi Berakhir Silahkan Login Kembali!", "errorTime");
                router.push("/auth/re-login");
            }
        };
        if (false) {}
        // Berlangganan untuk menangani respons di seluruh aplikasi
        axiosInstance.interceptors.response.use((response)=>{
            handleResponse(response);
            return response;
        }, (error)=>{
            handleResponse(error.response);
            throw error;
        });
    }, [
        axiosInstance,
        router
    ]);
    return axiosInstance;
}
// Ekspor default fungsi useAxiosConfig
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useAxiosConfig);


/***/ })

};
;