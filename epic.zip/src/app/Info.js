import React from "react";

export function Info() {
  return <div>ini halaman info</div>;
}
