import React from "react";

const HomeIndex = () => {
  return (
    <div>
      <h1>Selamat Datang di Proyek Next.js</h1>
      <p>Ini adalah halaman beranda.</p>
    </div>
  );
};

export default HomeIndex;
