// src/app/Kontak.js
import React from "react";

export function Kontak() {
  return <div>Ini halaman kontak</div>;
}
