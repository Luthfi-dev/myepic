import React from "react";
import Image from "next/image";
import DataPostingProses from "./Proses/DataPostingProses"

const DataPosting = () => {
    return (
        <>
        <div className="pagetitle">
          <nav>
            <ol className="breadcrumb">
              <li className="breadcrumb-item">
                <a href="/">Home</a>
              </li>
              <li className="breadcrumb-item active">Data Posting</li>
            </ol>
          </nav>
        </div>

        {/* section content */}

        {/* PROSES */}
        <div className="row">
          <div className="card">
            <div className="card-body p-3">
              <div className="col-lg-4">
                tes
              </div>
            </div>
          </div>
        </div>
            
        </>
    )
}

export default DataPosting;
