export const linkApi = "https://ex.luth.my.id/api/media";
export const publicApi = "https://ex.luth.my.id/media";
export const artikelApi = "https://ex.luth.my.id/api/artikel";
export const artikelPageApi = "https://ex.luth.my.id/api/artikelpage";
