module.exports = {
  // images: {
  //   remotePatterns: [
  //     {
  //       protocol: "https",
  //       hostname: "ex.luth.my.id",
  //       port: "",
  //       pathname: "/media/**",
  //     },
  //   ],
  // },
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "ex.luth.my.id",
        port: "",
        pathname: "/media/**",
      },
    ],
  },
};
