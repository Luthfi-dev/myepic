/**
 * @type {import('next').NextConfig}
 */
const nextConfig = {
  // reactStrictMode: true,
  // head: {
  //   link: [
  //     {
  //       rel: "icon",
  //       type: "image/png",
  //       href: "/assets/img/favicon.png",
  //     },
  //   ],
  // },
};

module.exports = nextConfig;
