import React from "react";
import { Info } from "../src/app/info";

const PageInfo = () => {
  return (
    <div>
      <Info />
    </div>
  );
};

export default PageInfo;
