// pages/page.js
import RootLayout from "../src/components/TemplateLayout";

export default function Page() {
  return (
    <RootLayout>
      <>halaman tampilan konten || cooming soon</>
    </RootLayout>
  );
}
